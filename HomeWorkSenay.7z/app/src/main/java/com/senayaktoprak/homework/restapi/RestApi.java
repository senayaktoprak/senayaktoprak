package com.senayaktoprak.homework.restapi;


import com.senayaktoprak.homework.models.GithubQ;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RestApi {

    @GET("repositories")
    Call<GithubQ> getSearchGithub(@Query("q") String queryT);
}
