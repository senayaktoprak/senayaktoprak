package com.senayaktoprak.homework.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.senayaktoprak.homework.R;
import com.senayaktoprak.homework.adapters.SenaAdapter;
import com.senayaktoprak.homework.models.GithubQ;
import com.senayaktoprak.homework.models.Item;
import com.senayaktoprak.homework.restapi.ManagerAll;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText searchEdit;
    private Button buttonSearch;
    private RecyclerView recyclerView;
    private SenaAdapter senaAdapter;
    private List<Item> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();


        buttonSearch.setOnClickListener(v -> {
            if (searchEdit.getText() != null && !searchEdit.getText().toString().equals("")) {
                getSearchApi(searchEdit.getText().toString());
            } else {
                Toast.makeText(MainActivity.this, "Please Enter Query Text", Toast.LENGTH_LONG).show();
            }
        });

    }

    private void initialize() {
        searchEdit = findViewById(R.id.searchEditText);
        buttonSearch = findViewById(R.id.searchBtn);
        recyclerView = findViewById(R.id.recyclerMain);
    }

    private void getSearchApi(String stringQuery) {

        itemList = new ArrayList<>();

        Call<GithubQ> githubQCall = ManagerAll.getInstance().getGitHub(stringQuery);

        githubQCall.enqueue(new Callback<GithubQ>() {
            @Override
            public void onResponse(Call<GithubQ> call, Response<GithubQ> response) {
                if (response.isSuccessful()) {
                    itemList = response.body().getItems();
                    Log.e("RidoS", itemList.size() + "");
                    senaAdapter = new SenaAdapter(MainActivity.this, itemList);
                    LinearLayoutManager lm = new LinearLayoutManager(MainActivity.this);
                    recyclerView.setLayoutManager(lm);
                    recyclerView.setAdapter(senaAdapter);

                } else {
                    Log.e("SenaE", response.message());
                }
            }

            @Override
            public void onFailure(Call<GithubQ> call, Throwable t) {
                Log.e("SenaE", t.getLocalizedMessage());
            }
        });
    }
}
