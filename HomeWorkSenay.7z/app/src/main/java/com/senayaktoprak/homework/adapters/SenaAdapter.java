package com.senayaktoprak.homework.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.senayaktoprak.homework.R;
import com.senayaktoprak.homework.models.Item;
import com.senayaktoprak.homework.ui.DetailsActivity;
import com.squareup.picasso.Picasso;

import java.util.List;

public class SenaAdapter extends RecyclerView.Adapter<SenaAdapter.SenaVHolder> {

    private Context context;
    private List<Item> itemList;

    public SenaAdapter(Context context, List<Item> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public SenaVHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.recycler_row, parent, false);

        return new SenaVHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SenaVHolder holder, int position) {
        Item items = itemList.get(position);

        if (items != null) {

            holder.textViewName.setText(items.getFullName());
            holder.textViewDescp.setText(items.getDescription());
            Picasso.get().load(items.getOwner().getAvatarUrl()).fit().into(holder.imageView);


            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(context, DetailsActivity.class);
                intent.putExtra("item", items);
                context.startActivity(intent);
            });
        }
    }

    @Override
    public int getItemCount() {
        if (itemList != null && itemList.size() > 0) {
            return itemList.size();
        } else {
            return 0;
        }
    }

    class SenaVHolder extends RecyclerView.ViewHolder {

        private TextView textViewName, textViewDescp;
        private ImageView imageView;

        SenaVHolder(@NonNull View itemView) {
            super(itemView);
            textViewDescp = itemView.findViewById(R.id.rowDescriptionText);
            textViewName = itemView.findViewById(R.id.rowNameText);
            imageView = itemView.findViewById(R.id.rowImageView);
        }
    }
}
