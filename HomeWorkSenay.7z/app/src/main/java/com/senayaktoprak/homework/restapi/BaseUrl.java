package com.senayaktoprak.homework.restapi;

class BaseUrl {


    //https://api.github.com/search/repositories
    static final String BASE_URL = "https://api.github.com/search/";

}
