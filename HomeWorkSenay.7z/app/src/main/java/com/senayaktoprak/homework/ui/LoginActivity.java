package com.senayaktoprak.homework.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.senayaktoprak.homework.R;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextUserName, editTextPassword;
    private Button loginBtn;
    private final String userandpass = "admin";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initialize();

        loginBtn.setOnClickListener(v -> {

            if (!editTextUserName.getText().toString().equals("")) { //check username null
                if (!editTextPassword.getText().toString().equals("")) { //check password null

                    String userName = editTextUserName.getText().toString();
                    String password = editTextPassword.getText().toString();

                    if (userName.equals(userandpass)) {
                        if (password.equals(userandpass)) {
                            startActivity(new Intent(LoginActivity.this, MainActivity.class));
                            finish();
                        } else {
                            errorToast("Invalid Password");
                        }
                    } else {
                        errorToast("Invalid User Name");
                    }
                }else {
                    errorToast("Password cannot be empty");

                }
            } else {
                errorToast("User Name cannot be empty");
            }
        });
    }

    private void initialize() {

        editTextUserName = findViewById(R.id.editTextUserName);
        editTextPassword = findViewById(R.id.editTextPassword);
        loginBtn = findViewById(R.id.buttonLogin);
    }

    private void errorToast(String error) {
        Toast.makeText(LoginActivity.this, error, Toast.LENGTH_LONG).show();
    }
}
