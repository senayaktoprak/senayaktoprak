package com.senayaktoprak.homework.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.senayaktoprak.homework.R;
import com.senayaktoprak.homework.models.Item;
import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView textViewName, textViewDescp, textViewLang;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        initialize();

    }

    private void initialize() {
        toolbar = findViewById(R.id.toolbarDetails);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        imageView = findViewById(R.id.detailsImageView);
        textViewName = findViewById(R.id.detailsNameText);
        textViewDescp = findViewById(R.id.detailsDescriptionText);
        textViewLang = findViewById(R.id.detailsLanguageText);

        Item item = (Item) getIntent().getSerializableExtra("item");

        if (item != null) {

            getSupportActionBar().setTitle(item.getName());
            textViewName.setText("FullName: " + item.getFullName());
            textViewDescp.setText("Description: " + item.getDescription());
            textViewLang.setText("Language: " + item.getLanguage());
            Picasso.get().load(item.getOwner().getAvatarUrl()).fit().into(imageView);
        }
    }

    //Back Buton Show..
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if (id == android.R.id.home) {
            super.onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
