package com.senayaktoprak.homework.restapi;

import com.senayaktoprak.homework.models.GithubQ;

import retrofit2.Call;

public class ManagerAll extends BaseManager {

    private static final ManagerAll ourgetInstance = new ManagerAll();

    public static synchronized ManagerAll getInstance() {

        return ourgetInstance;
    }

    public Call<GithubQ> getGitHub(String query) {

        return getRestApiClient().getSearchGithub(query);
    }
}
