package com.senayaktoprak.homework.restapi;

class BaseManager {

    RestApi getRestApiClient() {

        RestApiClient restApiClient = new RestApiClient(BaseUrl.BASE_URL);

        return restApiClient.getRestApi();
    }
}
